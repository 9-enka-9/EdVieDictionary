@php
    $titlePage="Blog"
@endphp
@extends('layouts.app')
@section('content')
    <div id="form-1" style="width: 100%; height:45em;">
        <div id="introduction">
            <h2 class="headline" style="margin-top:100px; color: black; font-size: 30px; text-align: center; width: 100%;">Trang này hiện đang phát triển</h2>
        </div>
    </div>
    @include('layouts.footer')
@endsection