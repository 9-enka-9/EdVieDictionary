<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?> | <?php if(isset($errorMsg)): ?>
        Not found
    <?php else: ?> <?php echo e($foundWord["tu"]); ?> <?php endif; ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/search.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/themify-icons/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <script src="https://kit.fontawesome.com/eef555952d.js" crossorigin="anonymous"></script>
</head>
<body>
    <div id="app">
        <div id="page">
            <?php $__env->startSection('header'); ?>
                <div id="header">
                    <div id="container">
                        <ul id="navbar">
                            <li>
                                <a href="<?php echo e(route('home')); ?>">
                                    <i class="icon ti-home"></i>
                                    <span class="text">Trang chủ</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('news')); ?>">
                                    <i class="icon ti-ink-pen"></i>
                                    <span class="text">Tin tức</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('blog')); ?>">
                                    <i class="icon ti-book"></i>
                                    <span class="text">Bài viết</span>
                                </a>
                            </li>
                        </ul>
                        <div id="logo">
                            <a href="<?php echo e(route('home')); ?>">
                                <h1 class="text">EdVie</h1>
                            </a>
                        </div>
                        <!-- Right Side Of Navbar -->
                            <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            
                            <div id="end_nav">
                                <div id="log_in">
                                    <i class="icon ti-user"></i>
                                    <a href="<?php echo e(route('login')); ?>" class="sign_in">Đăng nhập</a>
                                    <span class="line">|</span>
                                    <a href="<?php echo e(route('signup')); ?>" class="sign_up">Đăng ký</a>
                                </div>
                                <div id="language">
                                    <i class="icon ti-world"></i>
                                </div>
                            </div>
                            
                        <?php else: ?>
                            <div class="end_nav" style="display: flex">
                                <div class="dropdown">
                                    <div style="font-size: 20px; color: rgb(255, 255, 255);" class="dropbtn"> <i class="ti-user"></i> <?php echo e(Auth::user()->fullname); ?></div>
                                    <div class="frame-dropdown">
                                        <div class="dropdown-content">
                                        <a href=""> <i style="margin-right: 10px;" class="icon fa-solid fa-bookmark"></i> Lưu từ</a>
                                        <a href=""> <i style="margin-right: 10px;" class="icon fa-solid fa-key"></i> Thay đổi mật khẩu</a>
                                        <a href="<?php echo e(route('logout')); ?>"> <i style="margin-right: 10px;" class="icon fa-solid fa-right-from-bracket"></i> Đăng xuất</a>
                                        </div>
                                    </div>
                                </div>
                                <div id="language">
                                    <i class="icon ti-world"></i>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <form action="<?php echo e(route('toSearch')); ?>" class="search" method="POST"
                    style="display: flex; align-items: center; justify-content: center;">
                        <?php echo csrf_field(); ?>
                        <div class="header_search">
                            <input name="search" type="text" placeholder="Tra cứu Việt-Êde" class="input" />
                            <?php 
                            // if (isset($_POST["search"])) {
                            //     $timkiem = $_POST["search"];
                            //     include "change.php";
                            // } 
                            ?>
                            <?php if(isset($search)): ?>
                                
                            <?php endif; ?>                        
                            <div class="header_select">
                                <span class="header_search-select-label">Tiếng Việt</span>
                                <i class="ti-angle-down"></i>
                                <ul class="header_search-select-option">
                                    <li class="header_search-option-items">
                                        Tiếng Êde
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <button type="submit" onclick="myFunction()" id="search_icon" class="search_icon">
                            <i class="ti-search"></i>
                        </button>
                    </form>
                </div>
            <?php echo $__env->yieldSection(); ?>

            <main style="margin-top: 20vh;">
                <?php if(isset($errorMsg)): ?>
                    <div class="frame">
                        <div class="frame-word"> <?php echo e($word); ?> </div>
                        <div class="error-msg headline"><?php echo e($errorMsg); ?></div>
                    </div>
                <?php else: ?>
                    <div class="frame">
                        <div class="frame-word"> <?php echo e($foundWord["tu"]); ?> </div>
                        <div class="line"></div>
                        <div class="frame_content">
                            <div class="frame_content-means">
                                <?php if(isset($numbOfDef)): ?>
                                    <div class="headline">Nghĩa:</div>
                                    <?php for($i = 1; $i <= $numbOfDef; $i++): ?>
                                        <div class="text"> <?php echo e($foundWord["nghia_".$i]); ?> </div>
                                    <?php endfor; ?>
                                <?php else: ?>
                                    <div class="text"> <?php echo e($errorWord); ?> </div>
                                <?php endif; ?>

                            </div>
                            <div class="line"></div>
                            <div class="frame_content-example">
                                <?php if(isset($numbOfExa)): ?>
                                    <div class="headline">Ví dụ:</div>    
                                    <?php for($i = 1; $i <= $numbOfExa; $i++): ?>
                                        <div class="text"> <?php echo e($foundWord["cau_vd_".$i]); ?> : <?php echo e($foundWord["nghia_cau_vd_".$i]); ?> </div>
                                    <?php endfor; ?>
                                <?php else: ?>
                                    <div class="headline"><?php echo e($errorExa); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div> 
                <?php endif; ?>
                
            </main>
        </div>
        <?php if ($__env->exists('layouts.footer')) echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/edviecom/public_html/resources/views/layouts/search.blade.php ENDPATH**/ ?>