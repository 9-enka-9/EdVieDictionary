<?php
    $titlePage="Blog"
?>

<?php $__env->startSection('content'); ?>
    <div id="form-1" style="width: 100%; height:45em;">
        <div id="introduction">
            <h2 class="headline" style="margin-top:100px; color: black; font-size: 30px; text-align: center; width: 100%;">Trang này hiện đang phát triển</h2>
        </div>
    </div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EdVie\resources\views\blog.blade.php ENDPATH**/ ?>