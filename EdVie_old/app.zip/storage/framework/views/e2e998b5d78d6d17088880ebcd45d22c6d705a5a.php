<?php
    $titlePage="Login";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">    

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


    <title><?php echo e(config('app.name', 'Laravel')); ?> | <?php echo e($titlePage); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link rel="stylesheet" href="<?php echo e(asset('css/themify-icons/themify-icons.css')); ?>">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/login.css' )); ?>">
    <?php echo $__env->yieldSection(); ?>
</head>


<body>
    <div class="main">
        <form action="" method="POST" class="form" >
            <?php echo csrf_field(); ?>
            <h3>Đăng nhập</h3>
            <div id="form-1">

                <div class="form-group">
                    <label for="email" class="form-group-label">Email</label></br>
                    <input name="email" type="text" 
                    placeholder ="VD: ab123@gmail.com"  
                    class="form-group-input form-group-input form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    value='<?php echo e(old("email")); ?>'
                />
                </div>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span  class="error-message" style="color:red;" role="alert"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="form-group">
                    <label for="password" class="form-group-label">Mật khẩu</label></br>
                    <input name="password" type="password" 
                    placeholder="Nhập mật khẩu" 
                    class="form-group-input form-group-input form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    value='<?php echo e(old("password")); ?>'
                />
                </div>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span  class="error-message" style="color:red;" role="alert"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <button class="form-button">Đăng nhập</button>

                
                <?php if(session('all')): ?>
                    <span class="error-message" style="color:red;" role="alert"><?php echo e(session('all')); ?></span>
                <?php endif; ?>
            </div>
            
            <div id="form-text">
                <h2 class="text1">Hoặc</h2>
            </div>
            <div id="form-2">
                <div id="logo">
                <div class="gg">
                    <img class="img-logo"src="<?php echo e(asset('img/Google_icon.png')); ?>" alt="">
                    <p class="text-logo">Tiếp tục với Google</p>
                </div>

                <div class="fb">
                    <img class="img-logo"src="<?php echo e(asset('img/Facebook_icon.png')); ?>" alt="">
                    <p class="text-logo">Tiếp tục với Facebook</p>
                </div>
                </div>
            </div>
        </form>
    </div>
</body>
<?php /**PATH C:\xampp\htdocs\EdVie\resources\views\auth\login.blade.php ENDPATH**/ ?>