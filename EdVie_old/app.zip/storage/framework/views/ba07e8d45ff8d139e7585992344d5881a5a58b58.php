<?php
    $titlePage="Tin tức";
?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/news.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div   class="content" >
        <?php $__env->startSection('banner'); ?>
            <div  class="banner-show__test-list" style="user-select: auto;">
                <img src="<?php echo e(asset('img/News/banner-knowleadge.png')); ?>" alt="">
                <b  class="title__test-list" style="user-select: auto;">Danh sách tin tức</b> 
            </div> 
        <?php echo $__env->yieldSection(); ?>

        <?php $__env->startSection('posts'); ?>
            <div  class="container list-new-section" style="user-select: auto;">
                <div  class="test-document__list" style="user-select: auto;">
                    <a  href="../news/su_thi_dam_san" class="test-document__item" style="user-select: auto;">
                        <div  class="test-news__thumbnail" style="user-select: auto;">
                            <div  class="test-document__thumbnail-content" style="user-select: auto;">
                                <img  alt="" src="<?php echo e(asset('img/News/su_thi_dam_san/representation.jpg')); ?>" class="test-document__thumbnail-icon" style="user-select: auto;">
                            </div>
                        </div> 
                        <div  class="test-document__body-content" style="user-select: auto;">
                            <div  class="test-document__tag-title" style="user-select: auto;">
                                <div  class="test-document__title-desc" style="user-select: auto;">
                                    <b  class="test-document__question" style="user-select: auto;">Tóm tắt sử thi Đăm San</b> 
                                    <div  class="test-document__desc" style="text-overflow: ellipsis; user-select: auto;">
                                        Sử thi Đăm Săn là một trong những thiên sử thi anh hùng nổi tiếng của dân tộc Ê Đê (Việt Nam). Tên đầy đủ là Bài ca chàng Đam San (tiếng Ê Dê là Klei khan Y Đam San).
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>

                    <a  href="../news/su_thi_dam_san" class="test-document__item" style="user-select: auto;">
                        <div  class="test-news__thumbnail" style="user-select: auto;">
                            <div  class="test-document__thumbnail-content" style="user-select: auto;">
                                <img  alt="" src="<?php echo e(asset('img/News/su_thi_dam_san/representation.jpg')); ?>" class="test-document__thumbnail-icon" style="user-select: auto;">
                            </div>
                        </div> 
                        <div  class="test-document__body-content" style="user-select: auto;">
                            <div  class="test-document__tag-title" style="user-select: auto;">
                                <div  class="test-document__title-desc" style="user-select: auto;">
                                    <b  class="test-document__question" style="user-select: auto;">Tóm tắt sử thi Đăm San</b> 
                                    <div  class="test-document__desc" style="text-overflow: ellipsis; user-select: auto;">
                                        Sử thi Đăm Săn là một trong những thiên sử thi anh hùng nổi tiếng của dân tộc Ê Đê (Việt Nam). Tên đầy đủ là Bài ca chàng Đam San (tiếng Ê Dê là Klei khan Y Đam San).
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>

                    <a  href="../news/su_thi_dam_san" class="test-document__item" style="user-select: auto;">
                        <div  class="test-news__thumbnail" style="user-select: auto;">
                            <div  class="test-document__thumbnail-content" style="user-select: auto;">
                                <img  alt="" src="<?php echo e(asset('img/News/su_thi_dam_san/representation.jpg')); ?>" class="test-document__thumbnail-icon" style="user-select: auto;">
                            </div>
                        </div> 
                        <div  class="test-document__body-content" style="user-select: auto;">
                            <div  class="test-document__tag-title" style="user-select: auto;">
                                <div  class="test-document__title-desc" style="user-select: auto;">
                                    <b  class="test-document__question" style="user-select: auto;">Tóm tắt sử thi Đăm San</b> 
                                    <div  class="test-document__desc" style="text-overflow: ellipsis; user-select: auto;">
                                        Sử thi Đăm Săn là một trong những thiên sử thi anh hùng nổi tiếng của dân tộc Ê Đê (Việt Nam). Tên đầy đủ là Bài ca chàng Đam San (tiếng Ê Dê là Klei khan Y Đam San).
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>

                    <a  href="../news/su_thi_dam_san" class="test-document__item" style="user-select: auto;">
                        <div  class="test-news__thumbnail" style="user-select: auto;">
                            <div  class="test-document__thumbnail-content" style="user-select: auto;">
                                <img  alt="" src="<?php echo e(asset('img/News/su_thi_dam_san/representation.jpg')); ?>" class="test-document__thumbnail-icon" style="user-select: auto;">
                            </div>
                        </div> 
                        <div  class="test-document__body-content" style="user-select: auto;">
                            <div  class="test-document__tag-title" style="user-select: auto;">
                                <div  class="test-document__title-desc" style="user-select: auto;">
                                    <b  class="test-document__question" style="user-select: auto;">Tóm tắt sử thi Đăm San</b> 
                                    <div  class="test-document__desc" style="text-overflow: ellipsis; user-select: auto;">
                                        Sử thi Đăm Săn là một trong những thiên sử thi anh hùng nổi tiếng của dân tộc Ê Đê (Việt Nam). Tên đầy đủ là Bài ca chàng Đam San (tiếng Ê Dê là Klei khan Y Đam San).
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>

                    <a  href="../news/su_thi_dam_san" class="test-document__item" style="user-select: auto;">
                        <div  class="test-news__thumbnail" style="user-select: auto;">
                            <div  class="test-document__thumbnail-content" style="user-select: auto;">
                                <img  alt="" src="<?php echo e(asset('img/News/su_thi_dam_san/representation.jpg')); ?>" class="test-document__thumbnail-icon" style="user-select: auto;">
                            </div>
                        </div> 
                        <div  class="test-document__body-content" style="user-select: auto;">
                            <div  class="test-document__tag-title" style="user-select: auto;">
                                <div  class="test-document__title-desc" style="user-select: auto;">
                                    <b  class="test-document__question" style="user-select: auto;">Tóm tắt sử thi Đăm San</b> 
                                    <div  class="test-document__desc" style="text-overflow: ellipsis; user-select: auto;">
                                        Sử thi Đăm Săn là một trong những thiên sử thi anh hùng nổi tiếng của dân tộc Ê Đê (Việt Nam). Tên đầy đủ là Bài ca chàng Đam San (tiếng Ê Dê là Klei khan Y Đam San).
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>

                    <a  href="../news/su_thi_dam_san" class="test-document__item" style="user-select: auto;">
                        <div  class="test-news__thumbnail" style="user-select: auto;">
                            <div  class="test-document__thumbnail-content" style="user-select: auto;">
                                <img  alt="" src="<?php echo e(asset('img/News/su_thi_dam_san/representation.jpg')); ?>" class="test-document__thumbnail-icon" style="user-select: auto;">
                            </div>
                        </div> 
                        <div  class="test-document__body-content" style="user-select: auto;">
                            <div  class="test-document__tag-title" style="user-select: auto;">
                                <div  class="test-document__title-desc" style="user-select: auto;">
                                    <b  class="test-document__question" style="user-select: auto;">Tóm tắt sử thi Đăm San</b> 
                                    <div  class="test-document__desc" style="text-overflow: ellipsis; user-select: auto;">
                                        Sử thi Đăm Săn là một trong những thiên sử thi anh hùng nổi tiếng của dân tộc Ê Đê (Việt Nam). Tên đầy đủ là Bài ca chàng Đam San (tiếng Ê Dê là Klei khan Y Đam San).
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>

                </div> 
                <div  style="margin-top: 25px !important; float: right; user-select: auto;"><!---->
            </div>
        <?php echo $__env->yieldSection(); ?>

    </div>
    <?php if ($__env->exists('layouts.footer')) echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/edviecom/public_html/resources/views/news/news.blade.php ENDPATH**/ ?>