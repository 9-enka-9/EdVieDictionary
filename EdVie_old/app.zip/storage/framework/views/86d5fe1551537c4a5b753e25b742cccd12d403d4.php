<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">    

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link rel="stylesheet" href="<?php echo e(asset('css/themify-icons/themify-icons.css')); ?>">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/register.css')); ?>">
    
    <?php $__env->stopSection(); ?>     
    <?php echo $__env->yieldContent('css'); ?>
</head>


<body>

    <?php $__env->startSection('content'); ?>
    <div class="main">

        <form  class="form" action="<?php echo e(route('signup')); ?>" method="POST">
            <h3>Đăng kí</h3>   
            <div class="signup">

            <div id="form-1" >
                <div class="form-group" >
                    <label for="fullname" class="form-group-label">Tên đầy đủ</label></br>
                    <div>
                        <input name="fullname" 
                        type="text" 
                        placeholder="VD: Phạm Hiền Oanh" 
                        class="form-group-input form-control <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('fullname')); ?>"
                        autocomplete="fullname"
                        autofocus
                        required 
                        value="delete"
                        />
                    </div>
                    <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span  class="error-message" style="color:red;" role="alert"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group" >
                    <label for="email" class="form-group-label">Email</label></br>
                    <div>
                        <input name="email" 
                        type="text" 
                        placeholder ="VD: ab123@gmail.com"  
                        class="form-group-input form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="password" 
                        value="<?php echo e(old('email')); ?>"
                        autocomplete="email"
                        autofocus
                        required
                        value=<?php echo e(csrf_token()); ?>

                        />
                    </div>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span  class="error-message" style="color:red;" role="alert"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group" >
                    <label for="password" class="form-group-label">Mật khẩu</label></br>
                    <div>
                        <input name="password" 
                        type="password" 
                        placeholder ="Nhập lại mật khẩu"  
                        class="form-group-input form-control form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                        id="password-confirm"
                        value="<?php echo e(old('password')); ?>"
                        autocomplete="password"
                        required
                        value=<?php echo e(csrf_token()); ?>

                        />
                    </div>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span  class="error-message" style="color:red;" role="alert"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group" >
                    <label for="repeat_password" class="form-group-label">Xác nhận mật khẩu</label></br>
                    <div>
                        <input name="repeat_password" 
                        type="password" 
                        placeholder ="Nhập lại mật khẩu"  
                        class="form-group-input form-control <?php $__errorArgs = ['repeat_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="password-confirm"
                        autocomplete="new-password"
                        />
                    </div>
                    <?php $__errorArgs = ['repeat_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span  class="error-message" style="color:red;" role="alert"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button class="form-button btn btn-primary" id="register-btn" href="/<?php echo e(url('/signup')); ?>"><?php echo e(__('Đăng kí')); ?></button>
                <?php echo csrf_field(); ?>
            </div>
            
            <div id="form-text">
                <h2 class="text1">Hoặc</h2>
            </div>

            <div id="form-2">
                <div id="logo">
                    <a class="gg">
                        <img class="img-logo"src="<?php echo e(asset('img/Google_icon.png')); ?>" alt="">
                        <p class="text-logo">Tiếp tục với Google</p>
                    </a>

                    <a class="fb">
                        <img class="img-logo"src="<?php echo e(asset('img/Facebook_icon.png')); ?>" alt="">
                        <p class="text-logo">Tiếp tục với Facebook</p>
                    </a>
                </div>
            </div>
        </form>
    </div>
    <?php echo $__env->yieldSection(); ?>
</body>
</html>


<?php /**PATH /home/edviecom/public_html/resources/views/auth/signup.blade.php ENDPATH**/ ?>